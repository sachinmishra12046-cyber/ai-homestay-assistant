"use client";

import AuthLayout from "@/components/auth/AuthLayout";
import AuthInput from "@/components/auth/AuthInput";
import { GitFork, Globe, Lock, Mail, User } from "lucide-react";
import { useRouter } from "next/navigation";
import { FormEvent, useState } from "react";
import { useAuth } from "@/context/AuthProvider";
import { signIn } from "next-auth/react";

export default function SignupPage() {
  const router = useRouter();
  const { signup } = useAuth();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);

  const validate = () => {
    const next: Record<string, string> = {};
    if (!name.trim()) next.name = "Name is required";
    if (!email.trim()) next.email = "Email is required";
    else if (!/\S+@\S+\.\S+/.test(email)) next.email = "Enter a valid email";
    if (password.length < 6) next.password = "Minimum 6 characters";
    if (password !== confirm) next.confirm = "Passwords do not match";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    
    setIsLoading(true);
    try {
      await signup(name, email, password);
      router.replace("/dashboard");
      router.refresh();
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Signup failed. Please try again.";
      setErrors({ email: errorMessage });
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setIsGoogleLoading(true);
    try {
      await signIn("google", { callbackUrl: "/dashboard" });
    } catch (error) {
      console.error("Google sign-in error:", error);
      setErrors({ email: "Google sign-in failed. Please try again." });
    } finally {
      setIsGoogleLoading(false);
    }
  };

  return (
    <AuthLayout
      title="Join StayNest"
      subtitle="Create your account and get AI-powered homestay recommendations tailored to your travel style."
      footerText="Already have an account?"
      footerLink="Sign In"
      footerLinkHref="/login"
    >
      <div className="rounded-2xl border border-gray-100 bg-white p-8 shadow-xl dark:border-gray-800 dark:bg-gray-900">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Create Account</h2>
        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">Start your eco-travel journey today.</p>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <AuthInput label="Full Name" icon={User} value={name} onChange={(e) => setName(e.target.value)} error={errors.name} placeholder="Sachin Mishra" />
          <AuthInput label="Email Address" type="email" icon={Mail} value={email} onChange={(e) => setEmail(e.target.value)} error={errors.email} placeholder="you@email.com" />
          <AuthInput label="Password" type="password" icon={Lock} value={password} onChange={(e) => setPassword(e.target.value)} error={errors.password} />
          <AuthInput label="Confirm Password" type="password" icon={Lock} value={confirm} onChange={(e) => setConfirm(e.target.value)} error={errors.confirm} />

          <button type="submit" disabled={isLoading} className="w-full rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 py-3 text-sm font-semibold text-white shadow-lg hover:from-emerald-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed">
            {isLoading ? "Creating account..." : "Create Account"}
          </button>
        </form>

        <div className="relative my-6">
          <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-gray-200 dark:border-gray-700" /></div>
          <div className="relative flex justify-center text-xs uppercase"><span className="bg-white px-3 text-gray-400 dark:bg-gray-900">Or</span></div>
        </div>

        <div className="space-y-3">
          <button type="button" onClick={handleGoogleSignIn} disabled={isGoogleLoading} className="flex w-full items-center justify-center gap-2 rounded-xl border border-gray-200 py-3 text-sm font-medium text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
            <Globe className="h-4 w-4" /> {isGoogleLoading ? "Signing up with Google..." : "Continue with Google"}
          </button>
          <button type="button" onClick={() => alert('GitHub OAuth requires configuration. This feature is coming soon.')} className="flex w-full items-center justify-center gap-2 rounded-xl border border-gray-200 py-3 text-sm font-medium text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800 transition-colors">
            <GitFork className="h-4 w-4" /> Continue with GitHub
          </button>
        </div>
      </div>
    </AuthLayout>
  );
}
