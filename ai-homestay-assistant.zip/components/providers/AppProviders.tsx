"use client";

import { ThemeProvider } from "@/context/ThemeProvider";
import { WishlistProvider } from "@/context/WishlistProvider";
import { AuthProvider } from "@/context/AuthProvider";
import { NotificationProvider } from "@/context/NotificationProvider";
import ChatWidget from "@/components/ChatWidget";
import ErrorBoundary from "@/components/ErrorBoundary";
import { SessionProvider } from "next-auth/react";

export default function AppProviders({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <SessionProvider>
      <ThemeProvider>
        <AuthProvider>
          <NotificationProvider>
            <WishlistProvider>
              {children}
              <ErrorBoundary>
                <ChatWidget />
              </ErrorBoundary>
            </WishlistProvider>
          </NotificationProvider>
        </AuthProvider>
      </ThemeProvider>
    </SessionProvider>
  );
}
